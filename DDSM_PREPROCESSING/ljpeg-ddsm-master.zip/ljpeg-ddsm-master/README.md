Usage:

1. Get the repo
	```
	git clone https://github.com/nicholaslocascio/ljpeg.git

	```
2. Produce the jpeg binary.
	```
	cd jpegdir; make

	```
3. Edit `path_to_ddsm` string in convert.py 
	```
	python convert.py

	```
4. Run convert.py and wait a long time for it to finish
	```
	python convert.py

	```
